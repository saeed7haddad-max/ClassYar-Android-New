# ClassYar Android - File Bridge Repair (4.1)

This is the complete Android Studio/Gradle project source, not an APK.

## Build with GitHub Actions
1. Download this ZIP and extract it.
2. Open the extracted `ClassYar-Android` folder.
3. Upload/replace the contents of that folder in the root of your GitHub repository (keep `.github/workflows/build-apk.yml`).
4. In GitHub, open Actions -> Build ClassYar APK -> Run workflow.
5. Download the `ClassYar-Android-APK` artifact and extract the APK from it.

## Scope
- Keeps the original `index.html` app UI and application logic, except correcting the quick-backup filename sequence matcher so it recognizes the `CLASSYAR...json` filenames it creates.
- Adds/uses Android document-picker file saving for Blob downloads (PDF, Excel and JSON) and the SAF tree-folder bridge for quick backup.
- Cloud login/storage implementation is not changed.

## Important verification note
The ZIP archive and JavaScript syntax were checked. A full Android Gradle build and on-device tests were not available in this environment. Therefore this source package is not represented as a guaranteed tested APK. After building, test with a small quick backup and one PDF/Excel export before relying on it.
