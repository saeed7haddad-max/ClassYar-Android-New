import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { TextEncoder, TextDecoder } from 'node:util';

const html = fs.readFileSync(new URL('../app/src/main/assets/index.html', import.meta.url), 'utf8');
const scriptTags = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)];
let checked = 0;
for (const [, attrs, body] of scriptTags) {
  if (/\bsrc\s*=/.test(attrs) || /\btype\s*=\s*["']application\/(?:json|ld\+json)["']/i.test(attrs)) continue;
  new vm.Script(body, { filename: `inline-script-${++checked}.js` });
}
assert.ok(checked >= 5, `Expected several inline scripts, checked ${checked}`);
assert.match(html, /id=["']classyar-android-saf-bridge["']/);
assert.match(html, /window\.showDirectoryPicker\s*=\s*async function/);
assert.match(html, /window\.showOpenFilePicker\s*=\s*async function/);
assert.match(html, /window\.showSaveFilePicker\s*=\s*async function/);
assert.match(html, /window\.__classyarNativeSaveBlob/);
assert.match(html, /function downloadBlob\(name,blob\)\{if\(window\.__classyarNativeSaveBlob\)/);
assert.match(html, /quickBackupLoadDirectory\(\).*?__classyarNativeDirectory/s);
assert.match(html, /async function rememberHandle\(h\).*?__classyarNativeRememberFile/s);

// Exercise the JS adapter against a deterministic mock of the Android bridge.
const bridgeSource = scriptTags.find(([, attrs]) => /id=["']classyar-android-saf-bridge["']/.test(attrs))?.[2];
assert.ok(bridgeSource, 'Android bridge script exists');
const encode = value => Buffer.from(value, 'utf8').toString('base64');
const decode = value => Buffer.from(value, 'base64').toString('utf8');
const window = {};
const native = {
  pickDirectory: id => window.__cyNativeResolve(id, { uri: 'content://tree/demo' }),
  pickOpenFile: id => window.__cyNativeResolve(id, { uri: 'content://file/backup', name: 'backup.json' }),
  pickSaveFile: (id, name) => window.__cyNativeResolve(id, { uri: 'content://file/save', name }),
  getSavedDirectory: () => 'content://tree/demo',
  getSavedFileUri: () => 'content://file/backup',
  rememberFileUri: uri => { native.remembered = uri; },
  readFile: (id, uri) => window.__cyNativeResolve(id, { base64: encode('{"ok":true}'), size: 11 }),
  writeFile: (id, uri, b64) => { native.lastWrite = decode(b64); window.__cyNativeResolve(id, { ok: true }); },
  listDirectory: id => window.__cyNativeResolve(id, { items: [{ name: 'one.json', uri: 'content://file/one', directory: false }] }),
  createChildFile: (id, uri, name) => window.__cyNativeResolve(id, { uri: `content://file/${name}` }),
  saveBlob: (id, name, mime, b64) => { native.savedBlob = { name, mime, data: Buffer.from(b64, 'base64') }; window.__cyNativeResolve(id, { ok: true }); }
};
window.AndroidBridge = native;
const context = { window, AndroidBridge: native, TextEncoder, TextDecoder, Uint8Array, Map, Promise,
  btoa: value => Buffer.from(value, 'binary').toString('base64'),
  atob: value => Buffer.from(value, 'base64').toString('binary'), console };
vm.runInNewContext(bridgeSource, context, { filename: 'classyar-android-saf-bridge.js' });
const dir = await window.showDirectoryPicker();
assert.equal(dir.uri, 'content://tree/demo');
const entries = [];
for await (const item of dir.entries()) entries.push(item[0]);
assert.deepEqual(entries, ['one.json']);
const [file] = await window.showOpenFilePicker();
assert.equal(await (await file.getFile()).text(), '{"ok":true}');
const writable = await file.createWritable();
await writable.write('saved-content');
await writable.close();
assert.equal(native.lastWrite, 'saved-content');
await window.__classyarNativeSaveBlob('sample.pdf', new Blob(['pdf-bytes'], { type: 'application/pdf' }));
assert.equal(native.savedBlob.name, 'sample.pdf');
assert.equal(native.savedBlob.mime, 'application/pdf');
assert.equal(native.savedBlob.data.toString('utf8'), 'pdf-bytes');
console.log(`PASS: ${checked} inline JavaScript blocks parsed; SAF adapter, file read/write, directory iteration and Blob export passed mocked tests.`);
