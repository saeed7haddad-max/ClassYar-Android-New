@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (gradle %*) else (echo Gradle is not installed. Use GitHub Actions workflow or install Gradle 8.9.& exit /b 1)
