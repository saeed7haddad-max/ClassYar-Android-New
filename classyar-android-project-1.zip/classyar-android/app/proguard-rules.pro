# JavaScript bridge methods are exposed via @JavascriptInterface; minification is disabled.
