package ir.classyar.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pendingId: String? = null
    private var pendingKind: String? = null
    private var pendingWebFileChooser: ValueCallback<Array<Uri>>? = null
    private val prefs by lazy { getSharedPreferences("classyar_native", MODE_PRIVATE) }

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingId
        val kind = pendingKind
        pendingId = null; pendingKind = null
        if (id == null || kind == null) return@registerForActivityResult
        val data = result.data
        val selected = mutableListOf<Uri>()
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            data.data?.let { selected.add(it) }
            data.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { if (!selected.contains(it)) selected.add(it) }
            }
        }
        if (selected.isEmpty()) {
            pendingBlob.remove(id)
            pendingWebFileChooser?.onReceiveValue(null)
            pendingWebFileChooser = null
            callback(id, JSONObject().put("cancelled", true)); return@registerForActivityResult
        }
        val flags = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        selected.forEach { uri -> try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {} }
        val uri = selected.first()
        when (kind) {
            "webfile" -> {
                pendingWebFileChooser?.onReceiveValue(selected.toTypedArray())
                pendingWebFileChooser = null
            }
            "blob" -> { finishBlob(id, uri) }
            "dir" -> {
                prefs.edit().putString("directory_uri", uri.toString()).apply()
                callback(id, JSONObject().put("uri", uri.toString()).put("name", "پوشه انتخاب‌شده"))
            }
            "open" -> {
                prefs.edit().putString("file_uri", uri.toString()).apply()
                callback(id, JSONObject().put("uri", uri.toString()).put("name", displayName(uri)))
            }
            "save" -> {
                prefs.edit().putString("file_uri", uri.toString()).apply()
                callback(id, JSONObject().put("uri", uri.toString()).put("name", displayName(uri)))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(false)
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): android.webkit.WebResourceResponse? {
                val url = request?.url ?: return null
                return assetLoader.shouldInterceptRequest(url)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net") return false
                if (uri.scheme == "http" || uri.scheme == "https" || uri.scheme == "mailto" || uri.scheme == "tel") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                }
                return true
            }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    val message = JSONObject().put("message", error?.description?.toString() ?: "خطای بارگذاری").toString()
                    view?.evaluateJavascript("window.__cyNativePageError && window.__cyNativePageError($message)", null)
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?
            ): Boolean {
                if (pendingId != null) { filePathCallback?.onReceiveValue(null); return true }
                pendingWebFileChooser?.onReceiveValue(null)
                pendingWebFileChooser = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*")
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                val accepted = fileChooserParams?.acceptTypes?.filter { it.isNotBlank() }
                    ?.flatMap { it.split(',') }?.map { it.trim().lowercase() }?.filter { it.isNotBlank() } ?: emptyList()
                val mimeTypes = accepted.mapNotNull { token ->
                    if (token.contains('/')) token
                    else android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(token.removePrefix("."))
                }.distinct()
                if (mimeTypes.size == 1) intent.setType(mimeTypes.first())
                else if (mimeTypes.size > 1) intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
                if (fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                val id = "webfile-${System.nanoTime()}"
                launch("webfile", id, intent)
                return true
            }
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                android.util.Log.d("ClassYarWeb", "${consoleMessage.message()} -- ${consoleMessage.lineNumber()}")
                return true
            }
        }
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    override fun onDestroy() { pendingWebFileChooser?.onReceiveValue(null); pendingWebFileChooser = null; web.destroy(); super.onDestroy() }
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun launch(kind: String, id: String, intent: Intent) {
        runOnUiThread {
            if (pendingId != null) {
                pendingBlob.remove(id)
                if (kind == "webfile") { pendingWebFileChooser?.onReceiveValue(null); pendingWebFileChooser = null }
                callback(id, JSONObject().put("error", "یک انتخاب‌گر دیگر باز است.")); return@runOnUiThread
            }
            pendingId = id; pendingKind = kind
            try { picker.launch(intent) } catch (e: Exception) {
                pendingId = null; pendingKind = null
                if (kind == "webfile") { pendingWebFileChooser?.onReceiveValue(null); pendingWebFileChooser = null }
                pendingBlob.remove(id)
                callback(id, JSONObject().put("error", e.message ?: "باز کردن انتخاب‌گر ناموفق بود"))
            }
        }
    }

    private fun callback(id: String, value: JSONObject) {
        val safeId = JSONObject.quote(id)
        runOnUiThread { web.evaluateJavascript("window.__cyNativeResolve && window.__cyNativeResolve($safeId, $value)", null) }
    }

    private fun displayName(uri: Uri): String {
        var name = "فایل"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    private fun bytes(uri: Uri): ByteArray = contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: throw IllegalStateException("خواندن فایل ممکن نشد")

    private fun write(uri: Uri, data: ByteArray) {
        contentResolver.openOutputStream(uri, "wt")?.use { it.write(data); it.flush() }
            ?: throw IllegalStateException("نوشتن فایل ممکن نشد")
    }

    private fun list(uri: Uri): JSONArray {
        val result = JSONArray()
        val tree = DocumentsContractCompat.treeDocumentId(uri)
        val children = DocumentsContractCompat.childrenUri(uri, tree)
        contentResolver.query(children, arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE
        ), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0); val name = c.getString(1) ?: ""; val mime = c.getString(2)
                val child = DocumentsContractCompat.documentUri(uri, id)
                result.put(JSONObject().put("name", name).put("uri", child.toString())
                    .put("directory", mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR))
            }
        }
        return result
    }

    inner class AndroidBridge {
        @JavascriptInterface fun pickDirectory(id: String) {
            launch("dir", id, Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION))
        }
        @JavascriptInterface fun pickOpenFile(id: String) {
            launch("open", id, Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json")
                .addCategory(Intent.CATEGORY_OPENABLE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION))
        }
        @JavascriptInterface fun pickSaveFile(id: String, name: String, mime: String) {
            launch("save", id, Intent(Intent.ACTION_CREATE_DOCUMENT).setType(mime.ifBlank { "application/octet-stream" })
                .addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, name)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION))
        }
        @JavascriptInterface fun getSavedDirectory(): String = prefs.getString("directory_uri", "") ?: ""
        @JavascriptInterface fun getSavedFileUri(): String = prefs.getString("file_uri", "") ?: ""
        @JavascriptInterface fun rememberFileUri(uri: String) { prefs.edit().putString("file_uri", uri).apply() }
        @JavascriptInterface fun listDirectory(id: String, uri: String) {
            try { callback(id, JSONObject().put("items", list(Uri.parse(uri)))) }
            catch (e: Exception) { callback(id, JSONObject().put("error", e.message ?: "فهرست پوشه خوانده نشد")) }
        }
        @JavascriptInterface fun createChildFile(id: String, dirUri: String, name: String, mime: String) {
            try {
                val tree = Uri.parse(dirUri)
                val existing = list(tree)
                for (i in 0 until existing.length()) {
                    val item = existing.getJSONObject(i)
                    if (item.optString("name") == name && !item.optBoolean("directory")) {
                        callback(id, JSONObject().put("uri", item.getString("uri"))); return
                    }
                }
                val parentId = DocumentsContractCompat.treeDocumentId(tree)
                val child = android.provider.DocumentsContract.createDocument(contentResolver,
                    DocumentsContractCompat.documentUri(tree, parentId), mime, name)
                    ?: throw IllegalStateException("ایجاد فایل در پوشه ممکن نشد")
                callback(id, JSONObject().put("uri", child.toString()))
            } catch (e: Exception) { callback(id, JSONObject().put("error", e.message ?: "ایجاد فایل ناموفق بود")) }
        }
        @JavascriptInterface fun readFile(id: String, uri: String) {
            try {
                val raw = bytes(Uri.parse(uri))
                callback(id, JSONObject().put("base64", Base64.encodeToString(raw, Base64.NO_WRAP)).put("size", raw.size))
            } catch (e: Exception) { callback(id, JSONObject().put("error", e.message ?: "خواندن فایل ناموفق بود")) }
        }
        @JavascriptInterface fun writeFile(id: String, uri: String, base64: String) {
            try {
                val raw = Base64.decode(base64, Base64.DEFAULT)
                write(Uri.parse(uri), raw)
                val verified = bytes(Uri.parse(uri))
                if (!verified.contentEquals(raw)) throw IllegalStateException("تأیید محتوای نوشته‌شده ناموفق بود")
                callback(id, JSONObject().put("ok", true).put("size", verified.size))
            } catch (e: Exception) { callback(id, JSONObject().put("error", e.message ?: "نوشتن فایل ناموفق بود")) }
        }
        @JavascriptInterface fun saveBlob(id: String, name: String, mime: String, base64: String) {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).setType(mime.ifBlank { "application/octet-stream" })
                .addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, name)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            pendingBlob[id] = base64
            launch("blob", id, intent)
        }
    }

    private val pendingBlob = ConcurrentHashMap<String, String>()
    // SAF result handler also writes report payloads after user chooses a destination.
    private fun finishBlob(id: String, uri: Uri) {
        val encoded = pendingBlob.remove(id) ?: return
        try {
            val raw = Base64.decode(encoded, Base64.DEFAULT)
            write(uri, raw)
            if (!bytes(uri).contentEquals(raw)) throw IllegalStateException("تأیید فایل ذخیره‌شده ناموفق بود")
            callback(id, JSONObject().put("ok", true).put("size", raw.size).put("name", displayName(uri)))
        } catch (e: Exception) { callback(id, JSONObject().put("error", e.message ?: "ذخیره گزارش ناموفق بود")) }
    }
}

private object DocumentsContractCompat {
    fun treeDocumentId(uri: Uri): String = android.provider.DocumentsContract.getTreeDocumentId(uri)
    fun documentUri(tree: Uri, id: String): Uri = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id)
    fun childrenUri(tree: Uri, id: String): Uri = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
}
